<?php include_once "./../vistas/header/header.php"; ?>
<?php include "./../pages/doom/investigacion.php" ?>
<?php include_once "./../vistas/footer/footer.php"; ?>