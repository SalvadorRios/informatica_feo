<?php include_once "./../vistas/header/header.php"; ?>
<?php include "./../pages/doom/alumnos.php" ?>
<?php include_once "./../vistas/footer/footer.php"; ?>