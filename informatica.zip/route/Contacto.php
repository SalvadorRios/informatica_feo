<?php include_once "./../vistas/header/header.php"; ?>
<div class="contactColor">
<?php include "./../pages/doom/contacto.php" ?>
</div>
<?php include_once "./../vistas/footer/footer.php"; ?>