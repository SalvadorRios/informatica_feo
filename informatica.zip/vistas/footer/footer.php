<footer>
    Copyright © 2022 Rios y Soto | Preview informatica website
  </footer>
</body>

<!-- partial -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
<script src="../../../informatica/js/alumnos/menu.js"></script>
<script src="../../../informatica/js/carousel.js"></script>
<!-- bootstrap jala ptm --> 
<script src="../../../informatica/librerias/bootstrap-5.2.1-dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
<!-- scripts -->
    <script  src="../../../informatica/js/header.js"></script>
    <!-- perticles1 -->
    <script  src="../../../informatica/js/particles2.js"></script>

    <script src="../../../informatica/js/perticlesHomw1.js"></script>
    <script src="../../../informatica/js/configHome.js"></script>
    <!-- marinoBack -->
    <script src="../../../informatica/js/particlesBack.js"></script>
    <script src="../../../informatica/js/libraryParticlesHome.js"></script>

    <!-- jQuery -->
    <script src="../../../informatica/librerias/js/jquery-3.2.1.min.js"></script>
    <script src="../../../informatica/librerias/js/jquery-migrate-3.0.0.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="../../../informatica/librerias/js/bootstrap.min.js"></script>
    <!-- Animated text -->
    <script src="../../../informatica/librerias/js/jquery.textillate.js"></script>
    <script src="../../../informatica/librerias/js/jquery.lettering.js"></script>
    <script src="../../../informatica/librerias/js/jquery.fittext.js"></script>
    <!-- AjaxChimp js -->
    <script src="../../../informatica/librerias/js/jquery.ajaxchimp.min.js"></script>
    <!-- Swiper JS -->
    <script src="../../../informatica/librerias/js/swiper.min.js"></script>
    <!-- Custom -->
    <script src="../../../informatica/librerias/js/custom.js"></script>
    

</body>
</html>
